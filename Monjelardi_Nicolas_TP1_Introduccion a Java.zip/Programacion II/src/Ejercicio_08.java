public class Ejercicio_08 {
    public static void main(String[] args){

        int a = 5;
        int b = 2;
        int resultado = a / b;
        System.out.println("Resultado: " + resultado);

        /* El valor final de la variable resultado es 2

           esto ocurre porque al dividir 2 números enteros la parte decimal del resultado se elimina
         */

    }
}
