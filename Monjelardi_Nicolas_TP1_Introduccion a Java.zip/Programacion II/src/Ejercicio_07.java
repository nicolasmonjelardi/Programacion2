import java.util.Scanner;
public class Ejercicio_07 {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        System.out.print("Ingresa tu nombre: ");

        // String nombre = scanner.nextLine(); // ERROR }

        String nombre = scanner.nextLine();

        System.out.println("Hola, " + nombre);

        /* Corrección:

        El error estaba al querer usar nextInt() para capturar un dato de tipo String

        lo corregí intercambiando nextInt() por nextLine()  */

        scanner.close();
    }
}
