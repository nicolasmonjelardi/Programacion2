public class Ejercicio_02 {
    public static void main(String[] args) {

        String nombre = "Nicolas";
        int edad = 19;
        double altura = 1.76;
        boolean estudiante = true;

        System.out.println(nombre);

        System.out.println(edad);

        System.out.println(altura);

        System.out.println(estudiante);

    }
}
