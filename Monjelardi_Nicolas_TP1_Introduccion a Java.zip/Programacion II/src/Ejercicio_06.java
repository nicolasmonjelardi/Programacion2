import java.util.Scanner;

public class Ejercicio_06 {
    public static void main (String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.println("Ingrese el primer número: ");
        int numero1 = Integer.parseInt(sc.nextLine());

        System.out.println("Ingrese el segundo número: ");
        int numero2 = Integer.parseInt(sc.nextLine());

        double division = (double) numero1 / (double) numero2;
        System.out.println("Division (double): " + division);


    }
}
