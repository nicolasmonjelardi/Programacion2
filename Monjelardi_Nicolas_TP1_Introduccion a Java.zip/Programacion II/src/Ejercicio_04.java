import java.util.Scanner;

 class Ejercicio_04 {
    public static void main(String[] args){

        Scanner sc = new Scanner(System.in);

        System.out.println("Ingrese el primer número: ");
        int numero1 = Integer.parseInt(sc.nextLine());

        System.out.println("Ingrese el segundo número: ");
        int numero2 = Integer.parseInt(sc.nextLine());

        System.out.println("Suma: " + (numero1+numero2));
        System.out.println("Resta: " + (numero1-numero2) );
        System.out.println("Multiplicación: " + (numero1*numero2));
        System.out.println("División: " + (numero1/numero2));

        sc.close();



    }
}
