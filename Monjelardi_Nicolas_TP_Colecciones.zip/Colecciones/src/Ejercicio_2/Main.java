package Ejercicio_2;

public class Main {
    public static void main(String[] args) {
        // Crear autores
        Autor a1 = new Autor("A1", "Gabriel García Márquez", "Colombiana");
        Autor a2 = new Autor("A2", "Julio Cortázar", "Argentina");
        Autor a3 = new Autor("A3", "Isabel Allende", "Chilena");

        // Crear biblioteca
        Biblioteca biblio = new Biblioteca("Biblioteca Central");

        // Agregar libros
        biblio.agregarLibro("L1", "Cien años de soledad", 1967, a1);
        biblio.agregarLibro("L2", "Rayuela", 1963, a2);
        biblio.agregarLibro("L3", "La casa de los espíritus", 1982, a3);
        biblio.agregarLibro("L4", "El amor en los tiempos del cólera", 1985, a1);
        biblio.agregarLibro("L5", "Bestiario", 1951, a2);

        // Listar libros
        System.out.println("Listado de libros:");
        biblio.listarLibros();

        // Buscar libro por ISBN
        System.out.println("\nBuscar libro L2:");
        Libro buscado = biblio.buscarLibroPorIsbn("L2");
        if (buscado != null) buscado.mostrarInfo();

        // Filtrar por año
        System.out.println("\nLibros publicados en 1963:");
        biblio.filtrarLibrosPorAnio(1963);

        // Eliminar libro
        System.out.println("\nEliminar libro L3:");
        biblio.eliminarLibro("L3");
        biblio.listarLibros();

        // Cantidad total
        System.out.println("\nCantidad total de libros: " + biblio.obtenerCantidadLibros());

        // Mostrar autores
        System.out.println("\nAutores disponibles:");
        biblio.mostrarAutoresDisponibles();
    }
}
