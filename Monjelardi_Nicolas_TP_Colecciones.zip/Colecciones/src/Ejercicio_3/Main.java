package Ejercicio_3;

public class Main {
    public static void main(String[] args) {
        Universidad uni = new Universidad("UTN");

        Profesor prof1 = new Profesor("P1", "Juan Pérez", "Matemática");
        Profesor prof2 = new Profesor("P2", "Ana Gómez", "Programación");
        Profesor prof3 = new Profesor("P3", "Carlos López", "Historia");

        Curso c1 = new Curso("C1", "Álgebra");
        Curso c2 = new Curso("C2", "POO en Java");
        Curso c3 = new Curso("C3", "Historia Argentina");
        Curso c4 = new Curso("C4", "Estadística");
        Curso c5 = new Curso("C5", "Bases de Datos");

        uni.agregarProfesor(prof1);
        uni.agregarProfesor(prof2);
        uni.agregarProfesor(prof3);

        uni.agregarCurso(c1);
        uni.agregarCurso(c2);
        uni.agregarCurso(c3);
        uni.agregarCurso(c4);
        uni.agregarCurso(c5);

        // Asignar profesores
        uni.asignarProfesorACurso("C1", "P1");
        uni.asignarProfesorACurso("C2", "P2");
        uni.asignarProfesorACurso("C3", "P3");

        System.out.println("Listado de cursos:");
        uni.listarCursos();

        System.out.println("\nListado de profesores:");
        uni.listarProfesores();

        // Cambiar profesor de un curso
        System.out.println("\n profesor de C2 a P1:");
        uni.asignarProfesorACurso("C2", "P1");
        uni.listarCursos();

        // Eliminar curso
        System.out.println("\nEliminar curso C3:");
        uni.eliminarCurso("C3");
        uni.listarCursos();

        // Eliminar profesor
        System.out.println("\nEliminar profesor P1:");
        uni.eliminarProfesor("P1");
        uni.listarProfesores();
        uni.listarCursos();
    }
}
