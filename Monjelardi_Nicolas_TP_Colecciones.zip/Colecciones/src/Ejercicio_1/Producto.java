package Ejercicio_1;

public class Producto {

    //Atributos

    private String id;
    private String nombre;
    private double precio;
    private int cantidad;
    private CategoriaProducto categoria;

    //Constructor
    public Producto(String id, String nombre, double precio, int cantidad, CategoriaProducto categoria){

        this.id=id;
        this.nombre=nombre;
        this.precio=precio;
        this.cantidad=cantidad;
        this.categoria=categoria;
    }

    //Setters
    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    //Getters
    public String getId() {
        return id;
    }

    public CategoriaProducto getCategoria() {
        return categoria;
    }

    public int getCantidad() {
        return cantidad;
    }

    public double getPrecio() {
        return precio;
    }

    //Mostrar información del producto
    public void mostrarInfo(){
        System.out.printf(" ID: " + id + " | Nombre: " + nombre + " | Precio: $" + precio + " | Cantidad: " + cantidad + " | Categoría: " + categoria);
    }



}
