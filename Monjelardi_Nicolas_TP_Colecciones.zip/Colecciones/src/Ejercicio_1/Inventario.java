package Ejercicio_1;

import java.util.ArrayList;

public class Inventario {

    private ArrayList<Producto> productos;

    //Constructor
    public Inventario() {
        this.productos = new ArrayList<>();
    }

    //Agregar un producto al invantario
    public void agregarProducto(Producto p) {
        this.productos.add(p);
    }

    //Listar todos los productos del inventario
    public void listarProductos() {
        for (Producto p : productos) {
            p.mostrarInfo();
        }
    }

    //Buscar un producto por su id
    public Producto buscarProductoPorId(String id) {
        for (Producto p : productos) {
            if (p.getId().equals(id)) {
                return p;
            }
        }
        return null;
    }

    //Eliminar un producto del inventario
    public void eliminarProducto(String id) {
        productos.removeIf(p -> p.getId().equals(id));
    }


    //Actualizar stock
    public void actualizarStock(String id, int nuevaCantidad) {
        for (Producto p : productos) {
            if (p.getId().equals(id)) {
                if (nuevaCantidad >= 0) {
                    p.setCantidad(nuevaCantidad);
                }
            }
        }
    }

    //Filtrar por categoria
    public void filtrarPorCategoria(CategoriaProducto categoria) {
        for (Producto p : productos) {
            if (p.getCategoria() == categoria) {
                p.mostrarInfo();
            }
        }
    }

    //Obtener el stock total de productos
    public int obtenerTotalStock() {
        int total = 0;
        for (Producto p : productos) {
            total += p.getCantidad();
        }
        return total;
    }

    //Buscar el producto con mas stock
    public Producto obtenerProductoConMayorStock() {
        Producto mayor = null;
        int max = -1;
        for (Producto p : productos) {
            if (p.getCantidad() > max) {
                max = p.getCantidad();
                mayor = p;
            }
        }
        return mayor;
    }

    //Buscar productos por un rango de precios
    public void filtrarProductosPorPrecio(double min, double max) {
        for (Producto p : productos) {
            if (p.getPrecio() >= min && p.getPrecio() <= max) {
                p.mostrarInfo();
            }
        }
    }

    public void mostrarCategoriasDisponibles() {
        for (CategoriaProducto c : CategoriaProducto.values()) {
            System.out.println(c + " -> " + c.getDescripcion());
        }
    }
}