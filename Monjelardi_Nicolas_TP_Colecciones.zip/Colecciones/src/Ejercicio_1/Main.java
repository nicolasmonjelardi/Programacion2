package Ejercicio_1;

public class Main {
    public static void main(String[] args) {
        Inventario inv = new Inventario();

        inv.agregarProducto(new Producto("P1", "Arroz", 500, 20, CategoriaProducto.ALIMENTOS));
        inv.agregarProducto(new Producto("P2", "Celular", 150000, 5, CategoriaProducto.ELECTRONICA));
        inv.agregarProducto(new Producto("P3", "Camisa", 3000, 15, CategoriaProducto.ROPA));
        inv.agregarProducto(new Producto("P4", "Silla", 7000, 10, CategoriaProducto.HOGAR));
        inv.agregarProducto(new Producto("P5", "Notebook", 250000, 3, CategoriaProducto.ELECTRONICA));

        System.out.println("Listado de productos:");
        inv.listarProductos();

        System.out.println("\nBuscar producto por ID (P3):");
        Producto buscado = inv.buscarProductoPorId("P3");
        if (buscado != null) buscado.mostrarInfo();

        System.out.println("\nFiltrar por categoría ELECTRONICA:");
        inv.filtrarPorCategoria(CategoriaProducto.ELECTRONICA);

        System.out.println("\nEliminar producto P2:");
        inv.eliminarProducto("P2");
        inv.listarProductos();

        System.out.println("\nActualizar stock de P1 a 50:");
        inv.actualizarStock("P1", 50);
        inv.listarProductos();

        System.out.println("\nTotal stock disponible: " + inv.obtenerTotalStock());

        System.out.println("\nProducto con mayor stock:");
        Producto mayor = inv.obtenerProductoConMayorStock();
        if (mayor != null) mayor.mostrarInfo();

        System.out.println("\nFiltrar productos entre $1000 y $3000:");
        inv.filtrarProductosPorPrecio(1000, 3000);

        System.out.println("\nCategorías disponibles:");
        inv.mostrarCategoriasDisponibles();
    }
}
