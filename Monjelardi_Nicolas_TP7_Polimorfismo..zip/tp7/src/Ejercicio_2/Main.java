package Ejercicio_2;

public class Main {
    public static void main(String[] args) {
        Figura[] figuras = {
                new Circulo("Círculo", 5),
                new Rectangulo("Rectangulo", 4, 6)
        };

        for (Figura f : figuras) {
            System.out.println(f.nombre + " | Área: " + f.calcularArea());
        }
    }
}
