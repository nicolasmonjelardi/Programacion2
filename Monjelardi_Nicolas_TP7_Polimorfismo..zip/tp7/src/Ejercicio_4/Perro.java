package Ejercicio_4;

class Perro extends Animal {

    @Override
    public void hacerSonido() {
        System.out.println("Guau guau!");
    }
}
