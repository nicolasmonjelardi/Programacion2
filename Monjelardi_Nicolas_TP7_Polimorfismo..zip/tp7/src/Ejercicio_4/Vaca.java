package Ejercicio_4;

class Vaca extends Animal {

    @Override
    public void hacerSonido() {
        System.out.println("Muuu!");
    }
}