package Ejercicio_3;

class EmpleadoTemporal extends Empleado {
    private int diasTrabajados;
    private double pagoDia;

    public EmpleadoTemporal(String nombre, int diasTrabajados, double pagoDia) {
        super(nombre);
        this.diasTrabajados = diasTrabajados;
        this.pagoDia = pagoDia;
    }


    @Override
    public double calcularSueldo() {
        return diasTrabajados * pagoDia;
    }
}
