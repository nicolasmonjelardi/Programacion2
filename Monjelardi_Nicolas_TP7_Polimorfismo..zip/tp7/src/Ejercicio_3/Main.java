package Ejercicio_3;

public class Main {
    public static void main(String[] args) {
        Empleado[] empleados = {
                new EmpleadoPlanta("Juan", 50000),
                new EmpleadoTemporal("Ana", 20, 1500)
        };

        for (Empleado e : empleados) {
            System.out.println(e.nombre + " | Sueldo: " + e.calcularSueldo());

            if (e instanceof EmpleadoPlanta) {
                System.out.println("Es empleado de planta.");
            } else if (e instanceof EmpleadoTemporal) {
                System.out.println("Es empleado temporal.");
            }
        }
    }
}