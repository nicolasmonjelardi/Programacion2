package Ejercicio_1;

public class Main {
    public static void main(String[] args) {
        Auto a1 = new Auto("Toyota", "Corolla", 4);
        a1.mostrarInfo();
    }
}

