package Ejercicio_2;

public class Main {
    public static void main(String[] args) {
        Bateria b = new Bateria("Samsung-123", 4000);
        Celular c = new Celular("IMEI123456", "Samsung", "Galaxy S21", b);
        Usuario u = new Usuario("María López", "98765432");

        c.setUsuario(u);

        System.out.println(u);
        System.out.println(c);
    }
}

