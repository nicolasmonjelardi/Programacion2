package Ejercicio_9;

public class Main {
    public static void main(String[] args) {
        Paciente p = new Paciente("Nicolás Pérez", "OSDE");
        Profesional prof = new Profesional("Dra. Laura Gómez", "Cardiología");

        CitaMedica cita = new CitaMedica("12/05/2026", "10:30", p, prof);

        System.out.println(cita);
    }
}
