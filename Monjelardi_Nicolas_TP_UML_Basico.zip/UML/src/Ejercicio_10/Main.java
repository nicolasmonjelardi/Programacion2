package Ejercicio_10;

import java.time.LocalDate;

public class Main {
    public static void main(String[] args) {
        Titular t = new Titular("Nicolás Pérez", "12345678");
        CuentaBancaria cuenta = new CuentaBancaria("000123456789", 15000.50, "SEGURIDAD123", LocalDate.now(), t);

        System.out.println(cuenta);
    }
}
