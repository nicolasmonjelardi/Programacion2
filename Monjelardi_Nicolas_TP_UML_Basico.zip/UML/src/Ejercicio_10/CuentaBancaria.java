package Ejercicio_10;

public class CuentaBancaria {
    private String cbu;
    private double saldo;
    private ClaveSeguridad clave; // composición
    private Titular titular;      // asociación bidireccional

    public CuentaBancaria(String cbu, double saldo, String codigo, java.time.LocalDate ultimaModificacion, Titular titular) {
        this.cbu = cbu;
        this.saldo = saldo;
        this.clave = new ClaveSeguridad(codigo, ultimaModificacion); // composición
        this.titular = titular;
        titular.setCuenta(this); // mantener bidireccionalidad
    }

    @Override
    public String toString() {
        return "CuentaBancaria [cbu=" + cbu + ", saldo=" + saldo + ", clave=" + clave + ", titular=" + titular + "]";
    }
}
