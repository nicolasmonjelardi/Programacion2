package Ejercicio_7;

public class Main {
    public static void main(String[] args) {
        Motor m = new Motor("Diesel", "MTR12345");
        Vehiculo v = new Vehiculo("ABC123", "Toyota Corolla", m);
        Conductor c = new Conductor("Juan Pérez", "LIC98765");

        v.setConductor(c);

        System.out.println(c);
        System.out.println(v);
    }
}

