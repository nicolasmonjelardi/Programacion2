package Ejercicio_3;

public class Main {
    public static void main(String[] args) {
        Autor a = new Autor("Gabriel García Márquez", "Colombiana");
        Editorial e = new Editorial("Sudamericana", "Buenos Aires");
        Libro l = new Libro("Cien años de soledad", "978-84-376-0494-7", a, e);

        System.out.println(l);
    }
}

