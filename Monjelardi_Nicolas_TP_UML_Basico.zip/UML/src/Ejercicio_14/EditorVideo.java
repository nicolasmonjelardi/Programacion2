package Ejercicio_14;

public class EditorVideo {
    // dependencia de creación: crea Render a partir de Proyecto
    public void exportar(String formato, Proyecto proyecto) {
        Render render = new Render(formato, proyecto);
        System.out.println("Exportando proyecto: " + render);
    }
}
