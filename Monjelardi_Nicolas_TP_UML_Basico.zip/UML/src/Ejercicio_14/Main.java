package Ejercicio_14;

public class Main {
    public static void main(String[] args) {
        Proyecto proyecto = new Proyecto("Video Promocional", 120);
        EditorVideo editor = new EditorVideo();

        editor.exportar("MP4", proyecto);
    }
}

