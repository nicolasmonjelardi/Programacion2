package Ejercicio_4;

public class Main {
    public static void main(String[] args) {
        Banco b = new Banco("Banco Nación", "30-12345678-9");
        TarjetaDeCredito t = new TarjetaDeCredito("1234-5678-9012-3456", "12/2028", b);
        Cliente c = new Cliente("Ana Gómez", "45678901");

        t.setCliente(c);

        System.out.println(c);
        System.out.println(t);
    }
}
