package Ejercicio_5;

public class Main {
    public static void main(String[] args) {
        Computadora c = new Computadora("ASUS", "SN12345", "ROG STRIX B550-F", "AMD B550");
        Propietario p = new Propietario("Carlos Ruiz", "78965412");

        c.setPropietario(p);

        System.out.println(p);
        System.out.println(c);
    }
}
