package Ejercicio_5;

public class Computadora {
    private String marca;
    private String numeroSerie;
    private PlacaMadre placaMadre;   // composición
    private Propietario propietario;  // asociación bidireccional

    public Computadora(String marca, String numeroSerie, String modeloPlaca, String chipsetPlaca) {
        this.marca = marca;
        this.numeroSerie = numeroSerie;
        this.placaMadre = new PlacaMadre(modeloPlaca, chipsetPlaca); // composición
    }

    public void setPropietario(Propietario propietario) {
        this.propietario = propietario;
        propietario.setComputadora(this); // mantener bidireccionalidad
    }

    @Override
    public String toString() {
        return "Computadora [marca=" + marca + ", numeroSerie=" + numeroSerie + ", " + placaMadre + "]";
    }
}
