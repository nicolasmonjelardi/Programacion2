package Ejercicio_6;

public class Reserva {
    private String fecha;
    private String hora;
    private Mesa mesa;       // composición
    private Cliente cliente; // asociación bidireccional

    public Reserva(String fecha, String hora, int numeroMesa, int capacidadMesa) {
        this.fecha = fecha;
        this.hora = hora;
        this.mesa = new Mesa(numeroMesa, capacidadMesa); // composición
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
        cliente.setReserva(this); // mantener bidireccionalidad
    }

    @Override
    public String toString() {
        return "Reserva [fecha=" + fecha + ", hora=" + hora + ", " + mesa + "]";
    }
}
