package Ejercicio_6;

public class Main {
    public static void main(String[] args) {
        Reserva r = new Reserva("2026-05-15", "20:30", 12, 4);
        Cliente c = new Cliente("Lucía Fernández", "261-555-1234");

        r.setCliente(c);

        System.out.println(c);
        System.out.println(r);
    }
}
