package Ejercicio_13;

import java.time.LocalDate;

public class CodigoQR {
    private String contenido;
    private LocalDate fechaCreacion;

    public CodigoQR(String contenido, Usuario usuario) {
        this.contenido = contenido + " | Usuario: " + usuario;
        this.fechaCreacion = LocalDate.now();
    }

    @Override
    public String toString() {
        return "CodigoQR [contenido=" + contenido + ", fechaCreacion=" + fechaCreacion + "]";
    }
}
