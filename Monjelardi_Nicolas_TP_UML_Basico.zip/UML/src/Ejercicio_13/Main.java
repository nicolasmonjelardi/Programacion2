package Ejercicio_13;

public class Main {
    public static void main(String[] args) {
        Usuario u = new Usuario("Nicolás Pérez", "nicolas@mail.com");
        GeneradorQR generador = new GeneradorQR();

        // Usamos el método según la plantilla del PDF
        generador.generar("AccesoSistema", u);
    }
}
