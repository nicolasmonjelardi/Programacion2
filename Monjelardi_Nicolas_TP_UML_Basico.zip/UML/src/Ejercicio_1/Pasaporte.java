package Ejercicio_1;

public class Pasaporte {
    private String numero;
    private String fechaEmision;
    private Foto foto;       // composición
    private Titular titular; // asociación bidireccional

    public Pasaporte(String numero, String fechaEmision, Foto foto) {
        this.numero = numero;
        this.fechaEmision = fechaEmision;
        this.foto = foto;
    }

    public void setTitular(Titular titular) {
        this.titular = titular;
        titular.setPasaporte(this); // mantener la bidireccionalidad
    }

    public Titular getTitular() { return titular; }
    public Foto getFoto() { return foto; }

    @Override
    public String toString() {
        return "Pasaporte [numero=" + numero + ", fechaEmision=" + fechaEmision + ", " + foto + "]";
    }

}
