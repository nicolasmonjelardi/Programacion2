package Ejercicio_1;
import Ejercicio_1.Foto;
import Ejercicio_1.Pasaporte;
import Ejercicio_1.Titular;

public class Main {
    public static void main(String[] args) {
        Foto f = new Foto("imagen.jpg", "jpg");
        Pasaporte p = new Pasaporte("A12345", "2026-05-10", f);
        Titular t = new Titular("Juan Pérez", "12345678");

        p.setTitular(t);

        System.out.println("Titular: " + t);
        System.out.println("Pasaporte: " + p);

    }
}


