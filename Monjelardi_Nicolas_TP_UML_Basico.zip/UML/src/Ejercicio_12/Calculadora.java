package Ejercicio_12;

public class Calculadora {
    // dependencia de uso: usa Impuesto como parámetro
    public void calcular(Impuesto impuesto) {
        System.out.println("Calculando impuesto: " + impuesto.getMonto());
    }
}
