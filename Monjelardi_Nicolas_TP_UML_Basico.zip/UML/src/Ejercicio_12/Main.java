package Ejercicio_12;

public class Main {
    public static void main(String[] args) {
        Contribuyente c = new Contribuyente("Nicolás Pérez", "20-12345678-9");
        Impuesto i = new Impuesto(15000.0, c);

        Calculadora calc = new Calculadora();
        calc.calcular(i);

        System.out.println(i);
    }
}
