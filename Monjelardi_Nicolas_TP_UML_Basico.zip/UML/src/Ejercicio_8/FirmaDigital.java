package Ejercicio_8;

import java.time.LocalDate;

public class FirmaDigital {
    private String codigoHash;
    private LocalDate fecha;
    private Usuario usuario; // agregación

    public FirmaDigital(String codigoHash, LocalDate fecha, Usuario usuario) {
        this.codigoHash = codigoHash;
        this.fecha = fecha;
        this.usuario = usuario;
    }

    @Override
    public String toString() {
        return "FirmaDigital [codigoHash=" + codigoHash + ", fecha=" + fecha + ", usuario=" + usuario + "]";
    }
}
