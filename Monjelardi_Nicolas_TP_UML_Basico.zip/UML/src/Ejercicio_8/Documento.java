package Ejercicio_8;

public class Documento {
    private String titulo;
    private String contenido;
    private FirmaDigital firma; // composición

    public Documento(String titulo, String contenido, String codigoHash, java.time.LocalDate fecha, Usuario usuario) {
        this.titulo = titulo;
        this.contenido = contenido;
        this.firma = new FirmaDigital(codigoHash, fecha, usuario); // composición
    }

    @Override
    public String toString() {
        return "Documento [titulo=" + titulo + ", contenido=" + contenido + ", firma=" + firma + "]";
    }
}
