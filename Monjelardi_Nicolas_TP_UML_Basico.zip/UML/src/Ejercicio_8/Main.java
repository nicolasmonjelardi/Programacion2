package Ejercicio_8;

import java.time.LocalDate;

public class Main {
    public static void main(String[] args) {
        Usuario u = new Usuario("Nicolás Pérez", "nicolas@mail.com");
        Documento d = new Documento("Contrato Laboral", "Contenido del contrato...", "HASH12345", LocalDate.now(), u);

        System.out.println(d);
    }
}
