package Ejercicio_11;

public class Reproductor {
    // dependencia de uso: usa Cancion como parámetro
    public void reproducir(Cancion cancion) {
        System.out.println("Reproduciendo: " + cancion);
    }
}
