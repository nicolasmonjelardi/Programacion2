package Ejercicio_3;

public class Libro {
    String titulo;
    String autor;
    int añoPublicacion;

    //Getters

    public String getTitulo(String titulo){
        return titulo;
    }

    public String getAutor(String autor){
        return autor;
    }

    public int getAñoPublicacion(int añoPublicacion){
        return añoPublicacion;
    }

    //Setters

    public void setTitulo(String titulo){
        if (!titulo.trim().isEmpty()){
            this.titulo = titulo;
        }else{
            System.out.println("Error: El título no puede estar vacío.");
        }
    }

    public void setAutor(String autor){
        if (!autor.trim().isEmpty()){
            this.autor = autor;
        }else{
            System.out.println("Error: El autor no puede estar vacío.");
        }
    }

    public void setAñoPublicacion(int añoPublicacion){
        if (añoPublicacion >= 0 && añoPublicacion <= 2026){
            this.añoPublicacion = añoPublicacion;
        }else{
            System.out.println("Error: Rango de año inválido (0-2026).");
        }
    }

    //Método para mostrar la información del libro

    public void mostrarInfo(){
        System.out.println("Título: " + titulo);
        System.out.println("Autor: " + autor);
        System.out.println("Año de publicación: " + añoPublicacion);
    }

}
