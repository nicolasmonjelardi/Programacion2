package Ejercicio_3;

public class Ejercicio_3 {
    public static void main(String[] args) {

        Libro l1 = new Libro();

        //Asignar año de publicación inválido

        l1.setAñoPublicacion(2028);

        //Asignar año de publicación válido

        l1.setAñoPublicacion(2020);

        //Mostrar información final

        l1.mostrarInfo();
    }
}
