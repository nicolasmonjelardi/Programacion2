package Ejercicio_2;

public class Mascota {
    private String nombre;
    private int edad;
    private  String especie;

    //getters

    public String getNombre(String nombre){
        return nombre;
    }

    public String getEspecie(String especie){
        return especie;
    }

    public int getEdad(int edad){
        return edad;
    }

    //Setters

    public void setNombre(String nombre){
        if(!nombre.trim().isEmpty()){
            this.nombre = nombre;
        }else{
            System.out.println("Error: El nombre no puede estar vacío.");
        }
    }

    public void setEspecie(String especie){
        if (!especie.trim().isEmpty()){
            this.especie = especie;
        }else{
            System.out.println("Error: La especie no puede estar vacía.");
        }
    }

    public void setEdad(int edad){
        if (edad >= 0){
            this.edad = edad;
        }else{
            System.out.println("Error: La edad no puede ser negativa.");
        }
    }

    //Método para ver la información de la mascota

    public void mostrarInfo(){
        System.out.println("Nombre: " + nombre);
        System.out.println("Especie: " + especie);
        System.out.println("Edad: " + edad);
    }

    //Método para incrementar la edad de la mascota en 1

    public void cumplirAnios(){
        edad += 1;
        System.out.println(nombre + " Cumplió años!!");
    }
}
