package Ejercicio_2;

public class Ejercicio_2 {
    public static void main(String[] args) {

        Mascota m1 = new Mascota();

        //Asignar edad inválida

        m1.setEdad(-4);

        //Asignar datos válidos

        m1.setNombre("Tomi");
        m1.setEspecie("Perro");
        m1.setEdad(10);

        //Mostrar la información de la mascota

        m1.mostrarInfo();

        //Incrementar edad de la mascota

        m1.cumplirAnios();
        m1.cumplirAnios();
        m1.cumplirAnios();

        m1.mostrarInfo();

    }
}