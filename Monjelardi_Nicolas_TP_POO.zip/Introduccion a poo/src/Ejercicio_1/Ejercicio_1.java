package Ejercicio_1;

public class Ejercicio_1 {
    public static void main(String[] args) {

        Estudiante e1 = new Estudiante();

        //Datos Inválidos

        e1.setNombre("");
        e1.setApellido("");
        e1.setCurso("");
        e1.setCalificacion(12);

        //Datos Válidos

        e1.setNombre("Nicolás");
        e1.setApellido("Monjelardi");
        e1.setCurso("Comision 3");
        e1.setCalificacion(9);

        //Información del estudiante

        e1.mostrarInfo();

        //Subir o bajar la calificación del estudiante
        e1.subirCalificacion(1);
        e1.mostrarInfo();

        e1.subirCalificacion(20);

        //Bajar calificación
        e1.bajarCalificacion(5);
        e1.mostrarInfo();

        e1.bajarCalificacion(10);


    }
}