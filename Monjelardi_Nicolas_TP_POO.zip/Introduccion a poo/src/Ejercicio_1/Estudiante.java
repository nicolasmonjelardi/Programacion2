package Ejercicio_1;

public class Estudiante {
    private String nombre;
    private String apellido;
    private String curso;
    private double calificacion;

    //Getters

    public String getNombre(){
        return nombre;
    }

    public String getApellido(){
        return apellido;
    }

    public String getCurso(){
        return curso;
    }

    public double getCalificacion(){
        return calificacion;
    }

    //Setters

    public void setNombre(String nombre){
        if (nombre != null && !nombre.trim().isEmpty()){
            this.nombre = nombre;
        }else{
            System.out.println("Error: El nombre no puede estar vacío.");
        }
    }

    public void setApellido(String apellido){
        if (apellido != null && !apellido.trim().isEmpty()){
            this.apellido = apellido;
        }else{
            System.out.println("Error: El apellido no puede estar vacío.");
        }
    }

    public void setCurso(String curso){
        if (curso != null && !curso.trim().isEmpty()){
            this.curso = curso;
        }else{
            System.out.println("Error: El curso no puede estar vacío.");
        }
    }

    public void setCalificacion(double calificacion){
        if (calificacion >= 0 && calificacion <= 10){
            this.calificacion = calificacion;
        }else{
            System.out.println("Error: El rango de calificación es entre 0 y 10.");
        }
    }

    //Método para subir calificación

    public void subirCalificacion(double puntos){
        if (calificacion + puntos <= 10){
            calificacion += puntos;
        }else{
            System.out.println("Error: calificación fuera de rango (1-10).");
        }
    }

    //Método para bajar calificación

    public void bajarCalificacion(double puntos){
        if (calificacion - puntos >= 0){
            calificacion -= puntos;
        }else{
            System.out.println("Error: calificación fuera de rango (1-10).");
        }
    }

    //Método para mostrar la información del estudiante

    public void mostrarInfo(){
        System.out.println("Ejercicio_1.Estudiante: " + nombre + " " + apellido);
        System.out.println("Curso: " + curso);
        System.out.println("Calificación: " + calificacion);
    }
}

