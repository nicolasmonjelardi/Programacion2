package Ejercicio_5;

public class Ejercicio_5 {
    public static void main(String[] args){

        NaveEspacial nave = new NaveEspacial();

        // Asignar datos válidos

        nave.setNombre("n1");
        nave.setCombustible(50);

        // Intentar avanzar más de lo que el combustible permite

        nave.avanzar(600); // requiere 60 unidades, pero solo tiene 50

        // Recargar combustible

        nave.recargarCombustible(4000);

        // Despegar

        nave.despegar();

        // Avanzar correctamente

        nave.avanzar(200); // requiere 20 unidades

        // Mostrar estado final de la nave

        nave.mostrarEstado();
    }
}
