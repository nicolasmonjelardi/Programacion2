package Ejercicio_5;

import org.w3c.dom.ls.LSOutput;

public class NaveEspacial {

        private String nombre;
        private int combustible;

        //Constante
        private static final int CAPACIDAD_MAXIMA = 100;

        //Getters
        public String getNombre() { return nombre; }

        public int getCombustible() { return combustible; }

        //Setters
        public void setNombre(String nombre) {
            if (nombre != null && !nombre.trim().isEmpty()) {
                this.nombre = nombre;
            } else {
                System.out.println("Error: El Nombre no puede estar vacío.");
            }
        }

        public void setCombustible(int combustible) {
            if (combustible >= 0 && combustible <= CAPACIDAD_MAXIMA) {
                this.combustible = combustible;
            } else {
                System.out.println("Error: El rango de combustible es desde 0 hasta " + CAPACIDAD_MAXIMA);
            }
        }

        // Método para despegar
        public void despegar() {
            if (combustible >= 5) {
                combustible -= 5;
                System.out.println(nombre + " ha despegado. Combustible restante: " + combustible);
            } else {
                System.out.println("Error: No hay suficiente combustible para despegar.");
            }
        }

        //Método para que la nave avance

        public void avanzar(int distancia) {
            int requerido = distancia / 10; // 1 unidad cada 10 km
            if (combustible >= requerido) {
                combustible -= requerido;
                System.out.println(nombre + " avanzó " + distancia + " km. Combustible restante: " + combustible);
            } else {
                System.out.println("Error: No hay suficiente combustible para avanzar " + distancia + " km.");
            }
        }

        //Método para recargar el combustible

        public void recargarCombustible(int cantidad) {
            if (cantidad > 0) {
                if (combustible + cantidad <= CAPACIDAD_MAXIMA) {
                    combustible += cantidad;
                    System.out.println("Se recargaron " + cantidad + " unidades. Combustible actual: " + combustible);
                } else {
                    System.out.println("Error: Cantidad inválida para recargar.");
                }
            }


        }

        public void mostrarEstado() {
            System.out.println("Nave: " + nombre);
            System.out.println("Combustible: " + combustible + "/" + CAPACIDAD_MAXIMA);
        }
    }

