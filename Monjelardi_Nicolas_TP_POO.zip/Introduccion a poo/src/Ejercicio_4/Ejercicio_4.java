package Ejercicio_4;

public class Ejercicio_4 {
    public static void main(String[] args) {

        Gallina gallinaA = new Gallina();
        Gallina gallinaB = new Gallina();

        //Asignar una edad negativa

        gallinaA.setEdad(-2);

        //Simular que pusieron huevos

        gallinaA.ponerHuevo(2);
        gallinaB.ponerHuevo(1);

        //Mostrar estado actual

        gallinaA.mostrarEstado();
        gallinaB.mostrarEstado();
    }
}
