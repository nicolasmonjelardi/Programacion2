package Ejercicio_4;

public class Gallina {
    int idGallina;
    int edad;
    int huevosPuestos;

    //Getters

    public int getIdgallina(int idGallina){
        return idGallina;
    }

    public int getEdad(int edad){
        return edad;
    }

    public int getHuevosPuestos(int huevosPuestos){
        return huevosPuestos;
    }

    //Setters

    public void setEdad(int edad){
        if (edad >= 0){
            this.edad = edad;
        }else{
            System.out.println("Error: La edad no puede ser negativa.");
        }
    }

    public void setHuevosPuestos(int huevosPuestos){
        if (huevosPuestos >= 0){
            this.huevosPuestos = huevosPuestos;
        }else{
            System.out.println("Error: La cantidad de huevos no puede ser negativa.");
        }
    }

    //Método para poner huevos

    public void ponerHuevo(int huevos){
        if (huevos >= 0) {
            huevosPuestos += huevos;
        }else{
            System.out.println("Error: La cantidad de huevos no puede ser negativa.");
        }
    }

    //Método para envejecer

    public void envejecer(){
        edad += 1;
    }

    //Método para mostrar el estado actual de la gallina

    public void mostrarEstado(){
        System.out.println("Id: " + idGallina);
        System.out.println("Edad: " + edad);
        System.out.println("Huevos puestos: " + huevosPuestos);
    }
}
