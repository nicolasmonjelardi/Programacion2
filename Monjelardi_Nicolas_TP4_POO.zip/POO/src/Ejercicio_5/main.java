package Ejercicio_5;

public class main {
    public static void main(String[] args) {
        //Crear cuentas con ambos constructores
        Cuenta c1 = new Cuenta("Juan Pérez", 50000.0);
        Cuenta c2 = new Cuenta("María Gómez");

        //Demostrar el autoincremento del número de cuenta
        System.out.println(c1);
        System.out.println(c2);

        //Extraer más dinero del disponible
        c1.extraer(60000.0);
        c2.extraer(100.0);

        //Probar la conversión a dólares de consultarSaldo
        double cotizacionDolar = 1360.0;
        System.out.println("Saldo de c1 en dólares: " + c1.consultarSaldo(cotizacionDolar));

        //Mostrar el total de cuentas
        System.out.println("Total de cuentas creadas: " + Cuenta.mostrarTotalCuentas());
    }
}