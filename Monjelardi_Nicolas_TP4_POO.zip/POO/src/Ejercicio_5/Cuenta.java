package Ejercicio_5;

public class Cuenta {
    private final int numero;
    private String titular;
    private double saldo;
    private static int ultimoNumero = 100;
    private static int totalCuentas = 0;

    // Constructor principal
    public Cuenta(String titular, double saldoInicial) {
        this.numero = ++ultimoNumero;
        totalCuentas++;
        setTitular(titular);
        setSaldo(saldoInicial);
    }

    // Constructor sobrecargado
    public Cuenta(String titular) {
        this(titular, 0.0);
    }

    // Setters
    public void setTitular(String titular) {
        if (titular != null && !titular.isBlank()) {
            this.titular = titular;
        } else {
            System.out.println("Error: Titular inválido");
        }
    }

    private void setSaldo(double saldo) {
        if (saldo >= 0) {
            this.saldo = saldo;
        } else {
            System.out.println("Error: Saldo inválido");
            this.saldo = 0.0;
        }
    }

    // Métodos sobrecargados para consultar saldo
    public double consultarSaldo() {
        return saldo;
    }

    public double consultarSaldo(double cotizacionDolar) {
        if (cotizacionDolar > 0) {
            return saldo / cotizacionDolar;
        } else {
            System.out.println("Error: Cotización inválida");
            return 0.0;
        }
    }

    //Métodos para Extraer/Depositar dinero
    public void depositar(double monto) {
        if (monto > 0) {
            saldo += monto;
        } else {
            System.out.println("Error: Monto inválido");
        }
    }

    public void extraer(double monto) {
        if (monto > 0 && monto <= saldo) {
            double nuevoSaldo = saldo - monto;
            if (nuevoSaldo > 0) {
                saldo = nuevoSaldo;
            } else {
                System.out.println("Error: No se puede dejar saldo en 0");
            }
        } else {
            System.out.println("Error: Extracción inválida");
        }
    }

    // Métodos static para mostrar el total de cuentas
    public static int mostrarTotalCuentas() {
        return totalCuentas;
    }

    @Override
    public String toString() {
        return "Número de cuenta: " + numero +
                ", Titular: " + titular +
                ", Saldo: " + String.format("%.2f", saldo);
    }
}
