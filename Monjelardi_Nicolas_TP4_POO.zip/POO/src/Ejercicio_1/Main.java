package Ejercicio_1;


public class Main {
    public static void main(String[] args) {
        //Creamos objetos usando los 2 constructores
        Empleado e1 = new Empleado("Ana", "Programadora", 100000);
        Empleado e2 = new Empleado("Nicolás", "Tester");
        Empleado e3 = new Empleado("Laura", "Diseñadora");

        //métodos actualizarSalario() con datos válidos
        e1.actualizarSalario(10.00);
        e2.actualizarSalario(5000);

        //métodos actualizarSalario() con datos inválidos
        e3.actualizarSalario(-5);   // porcentaje inválido
        e3.actualizarSalario(-200); // valor absoluto inválido

        //Mostrar información de cada empleado
        System.out.println(e1);
        System.out.println(e2);
        System.out.println(e3);

        //Mostrar el total de empleados creados
        System.out.println("Total empleados: " + Empleado.mostrarTotalEmpleados());
    }
}