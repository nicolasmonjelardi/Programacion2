package Ejercicio_1;

public class Empleado {

    //Atributos
    private final int id;
    private String nombre;
    private String puesto;
    private double salario;

    //Contador de empleados
    private static int totalEmpleados = 0;

    //Setters
    public void setNombre(String nombre){
        if(nombre == null || nombre.isBlank()){
            System.out.println("Error: Nombre inválido");
        }else{
            this.nombre = nombre;
        }
    }

    public void setPuesto(String puesto){
        if(puesto == null || puesto.isBlank()){
            System.out.println("Error: Puesto inválido");
        }else{
            this.puesto = puesto;
        }
    }

    public void setSalario(double salario){
        if(salario <= 0){
            System.out.println("Error: Salario inválido");
        }else{
            this.salario = salario;
        }
    }

    //Constructor principal
    public Empleado(String nombre, String puesto, double salario){

        this.id = totalEmpleados++;
        setNombre(nombre);
        setPuesto(puesto);
        setSalario(salario);

    }

    //Constructor sobrecargado
    public Empleado(String nombre, String puesto){

        this(nombre, puesto, 1000.0);
    }

    //Getters


    //Métodos sobrecargados
    public void actualizarSalario(double aumento){

        if(aumento <= 0){
            System.out.println("Error: Aumento inválido");
        }else {
            double nuevoSalario = salario + ((salario * aumento) / 100);
            setSalario(nuevoSalario);
        }
    }

    public void actualizarSalario(int aumento){
        if(aumento <= 0){
            System.out.println("Error: Aumento inválido");
        }else {
            double nuevoSalario = salario + aumento;
            setSalario(nuevoSalario);
        }
    }

    //Método estático para mostrar la cantidad total de empleados
    public static int mostrarTotalEmpleados(){
        return totalEmpleados;
    }

    //toString
    @Override
    public String toString(){
        return "Ejercicio_1.Empleado: " + id +
                ", Nombre: " + nombre +
                ", Puesto: " + puesto +
                ", Salario: " + salario;
    }


}
