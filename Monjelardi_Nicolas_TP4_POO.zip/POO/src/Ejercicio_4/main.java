package Ejercicio_4;

public class main {
    public static void main(String[] args) {
        //Crear productos con ambos constructores
        Producto p1 = new Producto("Notebook", 200000.0);
        Producto p2 = new Producto("Mouse");

        //Probar las variantes de aplicarDescuento
        p1.aplicarDescuento(10);
        p2.aplicarDescuento(50, 50);

        //Crear un producto con precio negativo
        Producto p3 = new Producto("Celular", -5000.0);

        //Cambiar el IVA global y recalcular precios finales
        Producto.cambiarIVA(0.10);

        //Mostrar resultados
        System.out.println(p1);
        System.out.println(p2);
        System.out.println(p3);
    }
}
