package Ejercicio_4;

public class Producto {
    private String nombre;
    private double precioBase;
    private static double IVA = 0.21; // 21% por defecto

    //Constructor principal
    public Producto(String nombre, double precioBase) {
        setNombre(nombre);
        setPrecioBase(precioBase);
    }

    //Constructor sobrecargado
    public Producto(String nombre) {
        this(nombre, 100.0);
    }

    //Setters
    public void setNombre(String nombre) {
        if (nombre != null && !nombre.isBlank()) {
            this.nombre = nombre;
        } else {
            System.out.println("Error: Nombre inválido");
        }
    }

    public void setPrecioBase(double precioBase) {
        if (precioBase >= 0) {
            this.precioBase = precioBase;
        } else {
            System.out.println("Error: Precio inválido");
            this.precioBase = 0.0;
        }
    }

    // Métodos sobrecargados aplicarDescuento
    public void aplicarDescuento(double porcentaje) {
        if (porcentaje > 0 && porcentaje <= 100) {
            double nuevoPrecio = precioBase - (precioBase * porcentaje / 100);
            setPrecioBase(nuevoPrecio);
        } else {
            System.out.println("Error: Porcentaje inválido");
        }
    }

    public void aplicarDescuento(double porcentaje, double precioMinimo) {
        if (porcentaje > 0 && porcentaje <= 100) {
            double nuevoPrecio = precioBase - (precioBase * porcentaje / 100);
            if (nuevoPrecio < precioMinimo) {
                nuevoPrecio = precioMinimo; // garantiza límite
            }
            setPrecioBase(nuevoPrecio);
        } else {
            System.out.println("Error: Porcentaje inválido");
        }
    }

    //Métodos fiscales
    public double calcularPrecioFinal() {
        return precioBase + (precioBase * IVA);
    }

    public static void cambiarIVA(double nuevo) {
        if (nuevo >= 0 && nuevo <= 1) {
            IVA = nuevo;
        } else {
            System.out.println("Error: IVA inválido");
        }
    }

    // toString
    @Override
    public String toString() {
        return "Producto: " + nombre +
                ", Precio Base: " + precioBase +
                ", Precio Final:  " + calcularPrecioFinal();
    }
}
