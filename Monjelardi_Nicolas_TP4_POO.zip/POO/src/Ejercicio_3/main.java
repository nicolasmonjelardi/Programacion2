package Ejercicio_3;

public class main {
    public static void main(String[] args) {
        //Crear alumnos con ambos constructores
        Alumno a1 = new Alumno("Juan", 7.5);
        Alumno a2 = new Alumno("María");

        //Actualizar promedio con 2 métodos distintos
        a2.actualizarPromedio(8.0);
        double[] notas = {6.0, 7.0, 8.0, 9.0};
        a1.actualizarPromedio(notas);

        //Mostrar resultados resultados y verificar que apruebe
        System.out.println(a1);
        System.out.println(a2);

        //Cambiar la nota de aprobación global y volver a mostrar
        Alumno.cambiarNotaAprobacion(8.0);
        System.out.println("Después de cambiar la nota de aprobación global:");
        System.out.println(a1);
        System.out.println(a2);
    }
}
