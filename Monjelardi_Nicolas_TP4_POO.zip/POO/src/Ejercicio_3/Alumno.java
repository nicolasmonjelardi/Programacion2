package Ejercicio_3;

public class Alumno {
    private String nombre;
    private double promedio;
    private static double notaAprobacion = 6.0;

    //Constructor principal
    public Alumno(String nombre, double promedio) {
        setNombre(nombre);
        setPromedio(promedio);
    }

    //Constructor sobrecargado
    public Alumno(String nombre) {
        this(nombre, 0.0);
    }

    //Setters
    public void setPromedio(double promedio) {
        if (Double.isNaN(promedio)) {
            System.out.println("Error: Promedio inválido (NaN)");
            this.promedio = 0.0;
        } else if (promedio < 0) {
            this.promedio = 0.0;
        } else if (promedio > 10) {
            this.promedio = 10.0;
        } else {
            this.promedio = promedio;
        }
    }

    public void setNombre(String nombre) {
        if (nombre != null && !nombre.isBlank()) {
            this.nombre = nombre;
        } else {
            System.out.println("Error: Nombre inválido");
        }
    }

    // Métodos sobrecargados actualizarPromedio
    public void actualizarPromedio(double nuevoPromedio) {

        setPromedio(nuevoPromedio);
    }

    public void actualizarPromedio(double[] notas) {
        if (notas != null && notas.length > 0) {
            double suma = 0;
            for (double n : notas) {
                suma += n;
            }
            double promedioCalculado = suma / notas.length;
            setPromedio(promedioCalculado);
        } else {
            System.out.println("Error: Array de notas inválido");
        }
    }

    // Método para saber si aprueba
    public boolean aprobo() {
        return promedio >= notaAprobacion;
    }

    // Método estático para cambiar nota de aprobación
    public static void cambiarNotaAprobacion(double nueva) {
        if (nueva >= 0 && nueva <= 10) {
            notaAprobacion = nueva;
        } else {
            System.out.println("Error: Nota de aprobación inválida");
        }
    }

    // toString
    @Override
    public String toString() {
        return "Nombre: " + nombre +
                ", Promedio: " + promedio +
                ", ¿Aprueba? " + (aprobo() ? "Sí" : "No");
    }
}