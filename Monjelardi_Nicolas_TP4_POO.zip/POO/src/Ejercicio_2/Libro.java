package Ejercicio_2;

public class Libro {
    private String titulo;
    private String autor;
    private static String editorial = "independiente";

    //Constructor principal
    public Libro(String titulo, String autor) {
        setTitulo(titulo);
        setAutor(autor);
    }

    //Constructor sobrecargado
    public Libro(String titulo, String autor, String editorial) {
        this(titulo, autor);
        setEditorial(editorial);
    }

    //Setters
    public void setTitulo(String titulo) {
        if (titulo != null && !titulo.isBlank()) {
            this.titulo = titulo;
        } else {
            System.out.println("Error: Título inválido");
        }
    }

    public void setAutor(String autor) {
        if (autor != null && !autor.isBlank()) {
            this.autor = autor;
        } else {
            System.out.println("Error: Autor inválido");
        }
    }

    public void setEditorial(String editorial) {
        if (editorial != null && !editorial.isBlank()) {
            Libro.editorial = editorial;
        } else {
            System.out.println("Error: Editorial inválida");
        }
    }

    // Métodos sobrecargados para actualizar título
    public void actualizarTitulo(String nuevoTitulo) {
        setTitulo(nuevoTitulo);
    }

    public void actualizarTitulo(String prefijo, String nuevoTitulo) {
        setTitulo(prefijo + " " + nuevoTitulo);
    }

    // Método estático para cambiar editorial
    public static void cambiarEditorial(String nueva) {
        if (nueva != null && !nueva.isBlank()) {
            editorial = nueva;
        } else {
            System.out.println("Error: Editorial inválida");
        }
    }

    // toString
    @Override
    public String toString() {
        return "Título: " + titulo +
                ", Autor: " + autor +
                ", Editorial: " + editorial;
    }
}
