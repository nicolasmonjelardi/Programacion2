package Ejercicio_2;

public class main {
    public static void main(String[] args) {
        //Crear libros con y sin editorial explícita
        Libro l1 = new Libro("El Quijote", "Cervantes");
        Libro l2 = new Libro("Cien años de soledad", "García Márquez", "Sudamericana");

        //Usar las dos variantes de actualizarTitulo
        l1.actualizarTitulo("Don Quijote de la Mancha");
        l2.actualizarTitulo("Edición Especial", "Cien años de soledad");

        //Actualizar título con datos inválidos
        l1.actualizarTitulo("");

        //Mostrar los libros
        System.out.println(l1);
        System.out.println(l2);

        //Cambiar la editorial y volver a mostrar
        Libro.cambiarEditorial("Planeta");
        System.out.println("Después de cambiar la editorial global:");
        System.out.println(l1);
        System.out.println(l2);
    }
}