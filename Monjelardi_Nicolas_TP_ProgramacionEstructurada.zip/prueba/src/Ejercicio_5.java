import java.util.Scanner;

public class Ejercicio_5 {
    public static void main(String[] args){

        Scanner sc = new Scanner(System.in);

        int suma = 0;

        while (true) {

            System.out.print("Ingrese un número (0 para terminar): ");
            int num = Integer.parseInt(sc.nextLine());

            if (num == 0) {
                break;
            }

            if (num % 2 == 0) {
                suma += num;
            }
        }

        System.out.println("La suma de los números pares es: " + suma);

        sc.close();

        }

    }
