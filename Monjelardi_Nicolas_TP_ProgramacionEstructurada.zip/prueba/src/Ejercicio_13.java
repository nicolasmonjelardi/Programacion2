public class Ejercicio_13 {

    //mostrar precios
    public static void mostrarPrecios(double[] precios, int indice) {
        if (indice < precios.length) {
            System.out.println("Precio: $" + precios[indice]);
            mostrarPrecios(precios, indice + 1);
        }
    }

    public static void main(String[] args) {

        //array con precios
        double[] precios = {199.99, 299.5, 149.75, 399.0, 139.99};

        //precios originales
        System.out.println("Precios originales:");
        mostrarPrecios(precios, 0);

        //Modificar el precio de un producto
        precios[4] = 129.99;

        //precios modificados
        System.out.println("\nPrecios modificados:");
        mostrarPrecios(precios, 0);
    }
}
