import java.util.Scanner;

public class Ejercicio_9 {

    //calcular costo de envío
    public static double calcularCostoEnvio(double peso, String zona) {
        if (zona.equalsIgnoreCase("Nacional")) {
            return peso * 5;
        } else if (zona.equalsIgnoreCase("Internacional")) {
            return peso * 10;
        } else {
            return -1;
        }
    }

    //calcular total de compra
    public static double calcularTotalCompra(double precioProducto, double costoEnvio) {
        return precioProducto + costoEnvio;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        double precioProducto;
        double peso;
        String zona;

        // Validar precio del producto
        do {
            System.out.print("Ingrese el precio del producto: ");
            precioProducto = Double.parseDouble(sc.nextLine());
            if (precioProducto <= 0) {
                System.out.println("Error: El precio debe ser mayor que 0");
            }
        } while (precioProducto <= 0);

        // Validar peso
        do {
            System.out.print("Ingrese el peso del paquete en kg: ");
            peso = Double.parseDouble(sc.nextLine());
            if (peso <= 0) {
                System.out.println("Error: El peso debe ser mayor que 0");
            }
        } while (peso <= 0);

        // Validar zona
        do {
            System.out.print("Ingrese la zona de envío (Nacional/Internacional): ");
            zona = sc.nextLine();
            if (!zona.equalsIgnoreCase("Nacional") && !zona.equalsIgnoreCase("Internacional")) {
                System.out.println("Error: Zona inválida. Debe ser Nacional o Internacional");
            }
        } while (!zona.equalsIgnoreCase("Nacional") && !zona.equalsIgnoreCase("Internacional"));

        double costoEnvio = calcularCostoEnvio(peso, zona);

        double total = calcularTotalCompra(precioProducto, costoEnvio);

        System.out.println("El costo de envío es: " + costoEnvio);
        System.out.println("El total a pagar es: " + total);

        sc.close();
    }
}
