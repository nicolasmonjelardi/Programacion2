public class Ejercicio_12 {
    public static void main(String[] args) {

        //array con precios
        double[] precios = {199.99, 299.95, 149.75, 399.0, 89.99};

        //precios originales
        System.out.println("Precios originales:");
        for (double precio : precios) {
            System.out.println("Precio: $" + precio);
        }

        //Modificar el precio de un producto
        precios[2] = 129.99;

        //precios modificados
        System.out.println("\nPrecios modificados:");
        for (double precio : precios) {
            System.out.println("Precio: $" + precio);
        }
    }
}
