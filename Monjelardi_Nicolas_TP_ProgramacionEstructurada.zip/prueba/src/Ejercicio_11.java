import java.util.Scanner;

public class Ejercicio_11 {

    //Variable global
    public static final double DESCUENTO_ESPECIAL = 0.10;

    //calcular descuento especial
    public static void calcularDescuentoEspecial(double precio) {
        double descuentoAplicado = precio * DESCUENTO_ESPECIAL;
        double precioFinal = precio - descuentoAplicado;

        System.out.println("El descuento especial aplicado es: " + descuentoAplicado);
        System.out.println("El precio final con descuento es: " + precioFinal);
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        double precio;

        // Validar precio
        do {
            System.out.print("Ingrese el precio del producto: ");
            precio = Double.parseDouble(sc.nextLine());
            if (precio <= 0) {
                System.out.println("Error: El precio debe ser mayor que 0");
            }
        } while (precio <= 0);


        calcularDescuentoEspecial(precio);

        sc.close();
    }
}