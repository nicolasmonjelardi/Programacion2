import java.util.Scanner;

public class Ejercicio_10 {

    //actualizar stock
    public static int actualizarStock(int stockActual, int cantidadVendida, int cantidadRecibida) {
        return stockActual - cantidadVendida + cantidadRecibida;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int stockActual;
        int cantidadVendida;
        int cantidadRecibida;

        // Validar stock actual
        do {
            System.out.print("Ingrese el stock actual del producto: ");
            stockActual = Integer.parseInt(sc.nextLine());
            if (stockActual < 0) {
                System.out.println("Error: El stock actual no puede ser negativo");
            }
        } while (stockActual < 0);

        // Validar cantidad vendida
        do {
            System.out.print("Ingrese la cantidad vendida: ");
            cantidadVendida = Integer.parseInt(sc.nextLine());
            if (cantidadVendida < 0 || cantidadVendida > stockActual) {
                System.out.println("Error: La cantidad vendida debe estar entre 0 y el stock actual");
            }
        } while (cantidadVendida < 0 || cantidadVendida > stockActual);

        // Validar cantidad recibida
        do {
            System.out.print("Ingrese la cantidad recibida: ");
            cantidadRecibida = Integer.parseInt(sc.nextLine());
            if (cantidadRecibida < 0) {
                System.out.println("Error: La cantidad recibida no puede ser negativa");
            }
        } while (cantidadRecibida < 0);

        // Calcular nuevo stock
        int nuevoStock = actualizarStock(stockActual, cantidadVendida, cantidadRecibida);

        System.out.println("El nuevo stock del producto es: " + nuevoStock);

        sc.close();
    }
}
