import java.util.Scanner;

public class Ejercicio_4 {
    public static void main(String[] args){

        Scanner sc = new Scanner(System.in);

        System.out.print("Ingrese el precio del producto: ");
        double precio = Double.parseDouble(sc.nextLine());


        System.out.print("Ingrese la categoría del producto (A, B o C): ");
        String categoriaStr = sc.nextLine().toUpperCase();
        char categoria = categoriaStr.charAt(0);

        switch (categoria) {

            case 'A':
                System.out.println("Descuento aplicado: 10%");
                System.out.println("Precio final: " + (precio - (precio * 10 / 100)));
                break;

            case 'B':
                System.out.println("Descuento aplicado: 15%");
                System.out.println("Precio final: " + (precio - (precio * 15 / 100)));
                break;

            case 'C':
                System.out.println("Descuento aplicado: 20%");
                System.out.println("Precio final: " + (precio - (precio * 20 / 100)));
                break;
        }

        sc.close();
    }
}
