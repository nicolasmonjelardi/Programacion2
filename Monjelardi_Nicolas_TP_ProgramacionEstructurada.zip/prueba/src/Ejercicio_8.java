import java.util.Scanner;

public class Ejercicio_8 {

    //calcular precio final
    public static double calcularPrecioFinal(double precioBase, double impuesto, double descuento) {
        return precioBase + (precioBase * impuesto) - (precioBase * descuento);
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        double precioBase;
        double impuesto;
        double descuento;

        // Validar precio base
        do {
            System.out.print("Ingrese el precio base del producto: ");
            precioBase = Double.parseDouble(sc.nextLine());

            if (precioBase <= 0) {
                System.out.println("Error: El precio base debe ser mayor que 0");
            }

        } while (precioBase <= 0);

        // Validar impuesto
        do {
            System.out.print("Ingrese el impuesto en porcentaje (Ejemplo: 10 para 10%): ");
            impuesto = Double.parseDouble(sc.nextLine());

            if (impuesto < 0 || impuesto > 100) {
                System.out.println("Error: El impuesto debe estar entre 0 y 100");
            }

        } while (impuesto < 0 || impuesto > 100);

        // Validar descuento
        do {
            System.out.print("Ingrese el descuento en porcentaje (Ejemplo: 5 para 5%): ");
            descuento = Double.parseDouble(sc.nextLine());

            if (descuento < 0 || descuento > 100) {
                System.out.println("Error: El descuento debe estar entre 0 y 100.");
            }

        } while (descuento < 0 || descuento > 100);


        impuesto = impuesto / 100;
        descuento = descuento / 100;


        double precioFinal = calcularPrecioFinal(precioBase, impuesto, descuento);

        System.out.println("El precio final del producto es: " + precioFinal);

        sc.close();
    }
}
