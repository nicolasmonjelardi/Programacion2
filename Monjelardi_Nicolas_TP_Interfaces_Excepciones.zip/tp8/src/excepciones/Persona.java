package excepciones;

public class Persona {
    private int edad;

    public Persona(int edad) throws EdadInvalidaException {
        if (edad < 0 || edad > 120) {
            throw new EdadInvalidaException("Edad inválida: " + edad);
        }
        this.edad = edad;
    }

    public int getEdad() {
        return edad;
    }
}
