package excepciones;

public class Main {
    public static void main(String[] args) {
        try {
            Persona p1 = new Persona(30);
            System.out.println("Edad válida: " + p1.getEdad());

            Persona p2 = new Persona(-5);
            System.out.println("Edad válida: " + p2.getEdad());
        } catch (EdadInvalidaException e) {
            System.out.println("Excepción capturada: " + e.getMessage());
        }
    }
}



