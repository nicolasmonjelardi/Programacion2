package interfaces;

public interface Pago {
    public abstract void procesarPago(double monto);
}


