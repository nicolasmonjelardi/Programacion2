package interfaces;

public class Main {
    public static void main(String[] args) {
        Cliente cliente = new Cliente("Nicolás");
        Pedido pedido = new Pedido(cliente);

        pedido.agregarProducto(new Producto("Mouse", 5000));
        pedido.agregarProducto(new Producto("Teclado", 8000));

        System.out.println("Total pedido: $" + pedido.calcularTotal());

        TarjetaCredito pago = new TarjetaCredito();
        double montoConDescuento = pago.aplicarDescuento(pedido.calcularTotal());
        pago.procesarPago(montoConDescuento);

        pedido.cambiarEstado("Enviado");

    }
}

