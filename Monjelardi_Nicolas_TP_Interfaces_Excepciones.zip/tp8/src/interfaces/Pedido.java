package interfaces;

import java.util.ArrayList;

public class Pedido implements Pagable{

    private ArrayList<Producto> productos;
    private Cliente cliente;
    private String estado;

    public Pedido(Cliente cliente){
        this.productos = new ArrayList<>();
        this.cliente=cliente;
        this.estado="Pendiente";
    }

    public void agregarProducto(Producto p){
        productos.add(p);
    }

    @Override
    public double calcularTotal(){
        double total=0;

        for (Producto p : productos){
            total += p.calcularTotal();
        }
        return total;
    }

    public void cambiarEstado(String nuevoEstado){
        this.estado=nuevoEstado;
        cliente.notificar("El pedido cambio al estado: " + nuevoEstado);
    }
}
