package interfaces;

public interface Notificable {
    public abstract void notificar(String mensaje);
}